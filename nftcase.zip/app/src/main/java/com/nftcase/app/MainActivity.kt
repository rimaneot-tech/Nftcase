package com.nftcase.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 4107
    private val exportRequestCode = 4108
    private val importRequestCode = 4109
    private var pendingExport: String? = null

    inner class Bridge {
        @JavascriptInterface
        fun load(): String = try {
            val f = File(filesDir, "nftcase_save.json")
            if (f.exists()) f.readText() else ""
        } catch (e: Exception) { "" }

        @JavascriptInterface
        fun save(json: String) {
            try {
                val f = File(filesDir, "nftcase_save.json")
                val tmp = File(filesDir, "nftcase_save.tmp")
                tmp.writeText(json)
                if (!tmp.renameTo(f)) { f.writeText(json); tmp.delete() }
                getExternalFilesDir(null)?.let { File(it, "nftcase_save.json").writeText(json) }
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun exportJson(json: String, name: String) {
            runOnUiThread {
                pendingExport = json
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                try { startActivityForResult(i, exportRequestCode) } catch (e: Exception) { pendingExport = null }
            }
        }

        @JavascriptInterface
        fun importJson() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { startActivityForResult(i, importRequestCode) } catch (e: Exception) { }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0C10")
        window.navigationBarColor = Color.parseColor("#0B0C10")

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0C10"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.textZoom = 100
        web.settings.allowFileAccess = true

        // Передаём HTML input type=file системному выборщику Android.
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val intent = try {
                    params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                } catch (e: Exception) {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    return false
                }

                intent.type = "image/*"
                return try {
                    startActivityForResult(
                        Intent.createChooser(intent, "Выберите фотографию"),
                        fileChooserRequestCode
                    )
                    true
                } catch (e: Exception) {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == exportRequestCode) {
            val uri = data?.data
            val json = pendingExport
            pendingExport = null
            if (resultCode == Activity.RESULT_OK && uri != null && json != null) {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "Прогресс сохранён в файл", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == importRequestCode) {
            val uri = data?.data
            if (resultCode == Activity.RESULT_OK && uri != null) {
                try {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    web.evaluateJavascript("window.SV&&SV.onImport(" + JSONObject.quote(text) + ")", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось прочитать файл", Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback ?: return
            val result = if (resultCode == Activity.RESULT_OK) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                    ?: data?.data?.let { arrayOf(it) }
            } else null
            callback.onReceiveValue(result)
            filePathCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){var s=document.getElementById('sh');if(s&&s.classList.contains('on')){cs();return 1}return 0})()"
        web.evaluateJavascript(js) { r -> if (r != "1") finish() }
    }

    override fun onPause() {
        web.evaluateJavascript("window.SV&&SV.flush()", null)
        super.onPause()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        super.onDestroy()
    }
}
