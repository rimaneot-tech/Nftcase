package com.nftcase.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0C10")
        window.navigationBarColor = Color.parseColor("#0B0C10")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0C10"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.textZoom = 100
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){var s=document.getElementById('sh');if(s&&s.classList.contains('on')){cs();return 1}return 0})()"
        web.evaluateJavascript(js) { r -> if (r != "1") finish() }
    }
}
